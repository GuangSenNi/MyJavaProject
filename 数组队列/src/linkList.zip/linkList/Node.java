package linkList;

public class Node <E>{
	E e;
	Node<E> next;
	public Node() {
		super();
		next=null;
	}
	
}
